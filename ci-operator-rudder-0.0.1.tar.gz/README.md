ci-operator/rudder role
Process and parse Helm chart manifests and create dynamic inventory hosts for each resource definition.
